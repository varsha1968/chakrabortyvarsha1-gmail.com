package com.example.feasting;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Screen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen);
    }
}
